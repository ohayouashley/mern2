import React, { useEffect, useState } from "react";
import axios from "axios";
import { Navigate, useNavigate } from "react-router-dom";
import { useParams } from "react-router-dom";

const UpdateProduct = (props) => {
	const [item, setItem] = useState("");
	// const [price, setPrice] = useState("");
	// const [description, setDescription] = useState("");
	const navigate = useNavigate();
	const [errors, setErrors] = useState({});
	const { id } = useParams();

	useEffect(() => {
		axios
			.get(`http://localhost:8000/api/products/${id}`)
			.then((res) => setItem(res.data))
			.catch((e) => console.log(e));
	}, []);

	const submitHandler = (e) => {
		e.preventDefault();

		axios
			.put(`http://localhost:8000/api/products/${id}`, {
				item,
			})
			.then((e) => navigate("/"))
			.catch((e) => {
				console.log(e);
				setErrors(e.response.data.errors);
			});
	};

	return (
		<div>
			<div className="navbar">
				<header>Add Animal</header>
				<a href={`/`} className="btn btn-primary">
					Home
				</a>
			</div>
			<form onSubmit={submitHandler}>
				<div className="container">
					<div className="form-1">
						<div className="mb-3 col-9 p-4 bg-light text-dark custom_class_1">
							<div className="form-fields">
								<label>Title</label>
								{errors.title && (
									<span className="accent">{errors.title.message}</span>
								)}
								<input
									onChange={(e) => setItem({ ...item, title: e.target.value })}
									value={item.title}
									name="title"
									type="text"
								/>
							</div>

							<div className="form-fields">
								<label>Price</label>
								{errors.price && (
									<span className="accent">{errors.price.message}</span>
								)}
								<input
									onChange={(e) => setItem({ ...item, price: e.target.value })}
									value={item.price}
									name="price"
									type="text"
								/>

								<div className="form-fields">
									<label>Description</label>
									{errors.description && (
										<span className="accent">{errors.description.message}</span>
									)}
									<input
										onChange={(e) =>
											setItem({ ...item, description: e.target.value })
										}
										value={item.description}
										name="description"
										type="text"
									/>
								</div>
							</div>
						</div>
					</div>
					<div className="form-2">
						<div className="mb-3 col-10 p-4 bg-light text-dark">
							<div className="form-fields">
								<label>Skill</label>
								{errors.skill && (
									<span className="accent">{errors.skill.message}</span>
								)}
								<input
									onChange={(e) => setItem({ ...item, skill: e.target.value })}
									value={item.skill}
									name="skill"
									type="text"
								/>
							</div>

							<div className="form-fields">
								<label>Skill 2</label>
								{errors.skilltwo && (
									<span className="accent">{errors.skilltwo.message}</span>
								)}
								<input
									onChange={(e) =>
										setItem({ ...item, skilltwo: e.target.value })
									}
									value={item.skilltwo}
									name="skilltwo"
									type="text"
								/>
							</div>
							<div className="form-fields">
								<label>Skill 3</label>
								{errors.skillthree && (
									<span className="accent">{errors.skillthree.message}</span>
								)}
								<input
									onChange={(e) =>
										setItem({ ...item, skillthree: e.target.value })
									}
									value={item.skillthree}
									name="skillthree"
									type="text"
								/>
							</div>
						</div>
					</div>
				</div>

				<input type="submit" className="submit-input" value="Update" />
			</form>
		</div>
	);
};

export default UpdateProduct;
