import React, { useEffect, useState } from "react";
import axios from "axios";
import { Navigate, useNavigate } from "react-router-dom";
import { useParams } from "react-router-dom";

const DisplayOne = (props) => {
	const [item, setItem] = useState("");
	const [price, setPrice] = useState("");
	const [description, setDescription] = useState("");
	const navigate = useNavigate();
	const { id } = useParams();

	useEffect(() => {
		axios
			.get(`http://localhost:8000/api/products/${id}`)
			.then((res) => setItem(res.data))
			.catch((e) => console.log(e));
	}, []);

	const handleDelete = () => {
		axios
			.delete(`http://localhost:8000/api/products/${id}`)
			.then((e) => navigate("/"))
			.catch((e) => console.log(e));
	};

	return (
		<div>
			<div className="navbar">
				<h2>Pet Shelter:</h2>
				<a href={`/`} className="btn btn-primary">
					Home
				</a>
			</div>
			<div class="row">
				<div class="col-md-6">
					<div class="row"> Name</div>
					<div class="row"> Breed</div>
					<div class="row"> Description</div>
					<div class="row"> Skills</div>
				</div>
				<div class="col-md-6">
					<div class="row"> {item.title}</div>
					<div class="row"> {item.price}</div>
					<div class="row"> {item.description}</div>
					<div class="row">
						{" "}
						{item.skill}, {item.skilltwo}, {item.skillthree}{" "}
					</div>
				</div>
			</div>
			<button onClick={handleDelete} className="btn btn-warning">
				Adopt!
			</button>
		</div>
	);
};

export default DisplayOne;
