import axios from "axios";
import React, { useEffect, useState } from "react";
import ProductForm from "./ProductForm";

const DisplayAll = (props) => {
	const [list, setList] = useState([]);
	useEffect(() => {
		axios
			.get("http://localhost:8000/api/products")
			.then((e) => setList(e.data))
			.catch((e) => console.log(e));
	}, []);

	return (
		<div className="container-table">
			<div className="navbar">
				<h2>Pet Shelter:</h2>

				<a href={`/new`} className="btn btn-primary">
					Add new animal
				</a>
			</div>
			<div className="animals">
				<table className="table">
					<thead>
						<tr>
							<th>Name</th>
							<th>Type</th>
							<th>Description</th>
							<th>Update/Edit</th>
						</tr>
					</thead>
					<tbody>
						{list.map((item, index) => (
							<div key={index}>
								<tr>
									<td>{item.title}</td>
									<td>{item.price} </td>

									<td>{item.description}</td>
									<td>
										<a
											href={`/product/${item._id}/update`}
											className="btn btn-outline-primary"
										>
											Update
										</a>

										<a
											href={`/product/${item._id}/view`}
											class="btn btn-outline-dark"
										>
											View
										</a>
									</td>
								</tr>
							</div>
						))}
					</tbody>
				</table>
			</div>
		</div>
	);
};

export default DisplayAll;
