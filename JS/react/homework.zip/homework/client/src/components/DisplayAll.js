import axios from "axios";
import React, { useEffect, useState } from "react";
import ProductForm from "./ProductForm";

const DisplayAll = (props) => {
	const [list, setList] = useState([]);
	useEffect(() => {
		axios
			.get("http://localhost:8000/api/products")
			.then((e) => setList(e.data))
			.catch((e) => console.log(e));
	}, []);

	return (
		<div>
			<div className="navbar">
				<h2>Pet Shelter:</h2>

				<a href={`/new`} className="btn btn-primary">
					add a pet to the shelter
				</a>
			</div>
			<h3>These pets are looking for a good home</h3>
			<div className="container-table">
				<div className="animals">
					<table className="table">
						<thead>
							<tr>
								<th>Name</th>
								<th>Type</th>
								{/* <th>Description</th> */}
								<th>Actions</th>
							</tr>
						</thead>
						<tbody>
							{list.map((item, index) => (
								<div key={index}>
									<tr>
										<td>{item.title}</td>
										<td>{item.price} </td>

										{/* <td>{item.description}</td> */}
										<td>
											<a
												href={`/product/${item._id}/update`}
												className="btn btn-outline-primary"
											>
												Edit
											</a>

											<a
												href={`/product/${item._id}/view`}
												class="btn btn-outline-dark"
											>
												Details
											</a>
										</td>
									</tr>
								</div>
							))}
						</tbody>
					</table>
				</div>
			</div>
		</div>
	);
};

export default DisplayAll;
