import React from "react";

const Home = (props) => {
	return <div>Testing testing testing</div>;
};

export default Home;
