const ProductController = require("../controllers/product.controller");

module.exports = (app) => {
	// app.get("/api/jokes", JokeController.getAllJokes);
	app.post("/api/products", ProductController.newProduct);
	app.get("/api/products/:_id", ProductController.getJokeById);
	app.put("/api/products/:_id", ProductController.updateJoke);
	app.delete("/api/products/:_id", ProductController.deleteJoke);
};
