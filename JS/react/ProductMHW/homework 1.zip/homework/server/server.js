const express = require("express");
const cors = require("cors");
const app = express();

app.use(cors({ origin: "http://localhost:3000" }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

require("./config/mongoose.config");
require("./config/mongoose.product.routes")(app);
// require("./routes/author.routes")(app); ::change author route

app.listen(8000, () => {
	console.log("Listening at Port 8000");
});
