import React, { useState } from "react";
import axios from "axios";
import { Navigate, useNavigate } from "react-router-dom";

const ProductForm = (props) => {
	const [title, setTitle] = useState("");
	const [price, setPrice] = useState("");
	const [description, setDescription] = useState("");
	const navigate = useNavigate();
	const [errors, setErrors] = useState({});

	const submitHandler = (e) => {
		e.preventDefault();

		axios
			.post("http://localhost:8000/api/products", {
				title,
				price,
				description,
			})
			.then((e) => navigate("/"))
			.catch((e) => {
				console.log(e);
				setErrors(e.response.data.errors);
			});
	};

	return (
		<div>
			<header>Product Form</header>

			<form onSubmit={submitHandler}>
				<div className="form-fields">
					<label>Title</label>
					{errors.title && (
						<span className="accent">{errors.title.message}</span>
					)}
					<input
						onChange={(e) => setTitle(e.target.value)}
						value={title}
						name="title"
						type="text"
					/>
				</div>

				<div className="form-fields">
					<label>Price</label>
					{errors.price && (
						<span className="accent">{errors.price.message}</span>
					)}
					<input
						onChange={(e) => setPrice(e.target.value)}
						value={price}
						name="price"
						type="text"
					/>

					<div className="form-fields">
						<label>Description</label>
						{errors.description && (
							<span className="accent">{errors.description.message}</span>
						)}
						<input
							onChange={(e) => setDescription(e.target.value)}
							value={description}
							name="description"
							type="text"
						/>
					</div>
				</div>

				<input type="submit" className="submit-input" value="Create" />
			</form>
		</div>
	);
};

export default ProductForm;
