import axios from "axios";
import React, { useEffect, useState } from "react";
import ProductForm from "./ProductForm";

const DisplayAll = (props) => {
	const [list, setList] = useState([]);
	useEffect(() => {
		axios
			.get("http://localhost:8000/api/products")
			.then((e) => setList(e.data))
			.catch((e) => console.log(e));
	}, []);

	return (
		<div>
			{list.map((item, index) => (
				<div key={index}>
					<a href={`/product/${item._id}/update`}>{item.title} Update</a>
					<a href={`/product/${item._id}/view`}>{item.title} View</a>
				</div>
			))}
		</div>
	);
};

export default DisplayAll;
