import React, { useEffect, useState } from "react";
import axios from "axios";
import { Navigate, useNavigate } from "react-router-dom";
import { useParams } from "react-router-dom";

const DisplayOne = (props) => {
	const [item, setItem] = useState("");
	// const [price, setPrice] = useState("");
	// const [description, setDescription] = useState("");
	const navigate = useNavigate();
	const { id } = useParams();

	useEffect(() => {
		axios
			.get(`http://localhost:8000/api/products/${id}`)
			.then((res) => setItem(res.data))
			.catch((e) => console.log(e));
	}, []);

	const handleDelete = () => {
		axios
			.delete(`http://localhost:8000/api/products/${id}`)
			.then((e) => navigate("/"))
			.catch((e) => console.log(e));
	};

	return (
		<div>
			<button onClick={handleDelete}>delete</button>
		</div>
	);
};

export default DisplayOne;
